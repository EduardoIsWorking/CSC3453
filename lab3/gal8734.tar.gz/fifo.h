// fifo.h
#ifndef FIFO_H
#define FIFO_H
#include "pager.h"
void runFIFO(const Page *refs, int n, int F, PolicyReport *out);
#endif
