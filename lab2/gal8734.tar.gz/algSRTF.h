#ifndef ALG_SRTF_H
#define ALG_SRTF_H
#include "sim.h"
int runSRTF(PCB *pcbs, int n, const char *outPath);
#endif
